# central_server.py
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np
import vs
import joblib
import requests
import logging

app = FastAPI()

logging.basicConfig(level=logging.INFO)

class ClientData(BaseModel):
    client_id: int
    url: str

class TrainRequest(BaseModel):
    epochs: int

class PredictRequest(BaseModel):
    client_id: int

central_model = None
client_outputs = {}
client_urls = {}

@app.post("/register_client")
async def register_client(client_data: ClientData):
    client_urls[client_data.client_id] = client_data.url
    logging.info(f"Client {client_data.client_id} registered successfully")
    return {"message": f"Client {client_data.client_id} registered successfully"}

@app.post("/train")
async def train(request: TrainRequest):
    global central_model
    
    for epoch in range(request.epochs):
        # Collect outputs and labels from all clients
        all_outputs = []
        all_labels = []
        for client_id, url in client_urls.items():
            response = requests.post(f"{url}/forward", json={"client_id": client_id})
            if response.status_code == 200:
                data = response.json()
                all_outputs.append(np.array(data["output"]))
                all_labels.append(np.array(data["labels"]))
                logging.info(f"labels {all_labels}")
            else:
                raise HTTPException(status_code=500, detail=f"Error getting output from client {client_id}")

        # Initialize or update central model
        if central_model is None:
            total_features = sum(output.shape[1] for output in all_outputs)
            central_model = vs.create_model(total_features, is_central=True)
            logging.info(f"Initialized central model with {total_features} features")

        # Central forward pass
        logging.info(f"outputs {all_outputs}")
        central_input = np.concatenate(all_outputs, axis=1)
        logging.info(f"Central input shape: {central_input.shape}")
        try:
            central_output = vs.forward_pass(central_model, central_input)
        except ValueError as e:
            logging.error(f"Error during forward pass: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Error during forward pass: {str(e)}")

        # Calculate loss
        y = all_labels[0]
        logging.info(f"Central output shape: {central_output.shape}, y shape: {y.shape}")
        
        if central_output.shape[0] != y.shape[0]:
            logging.error(f"Shape mismatch: central_output {central_output.shape}, y {y.shape}")
            raise HTTPException(status_code=500, detail="Shape mismatch between model output and labels")
        
        loss = vs.calculate_loss(central_output, y)

        # Backward pass
        dvalues = central_output - y.reshape(-1, 1)
        dvalues = vs.backward_pass(central_model, dvalues)

        # Split gradients for client models
        client_gradients = np.split(dvalues, len(client_urls), axis=1)

        # Send gradients back to clients
        for (client_id, url), gradients in zip(client_urls.items(), client_gradients):
            response = requests.post(f"{url}/backward", json={"client_id": client_id, "gradients": gradients.tolist()})
            if response.status_code != 200:
                raise HTTPException(status_code=500, detail=f"Error sending gradients to client {client_id}")

        # Update central model
        vs.update_model(central_model)

        if epoch % 1 == 0:
            accuracy = vs.calculate_accuracy(central_output, y)
            logging.info(f'Epoch: {epoch}, Accuracy: {accuracy:.2f}, Loss: {loss:.2f}')

    # Save central model after training
    joblib.dump(central_model, 'central_model.joblib')

    return {"message": "Training completed"}

@app.post("/predict")
async def predict(request: PredictRequest):
    if central_model is None:
        raise HTTPException(status_code=400, detail="Model not trained yet")

    # Collect outputs from all clients for the specific user
    client_outputs = []
    for client_id, url in client_urls.items():
        response = requests.post(f"{url}/predict", json={"client_id": request.client_id})
        if response.status_code == 200:
            client_outputs.append(np.array(response.json()["output"]))
        elif response.status_code == 404:
            # User not found in this client's data, skip
            continue
        else:
            raise HTTPException(status_code=500, detail=f"Error getting prediction from client {client_id}")

    if not client_outputs:
        raise HTTPException(status_code=404, detail=f"User {request.client_id} not found in any client's data")

    # Central prediction
    logging.info(f"predictions {client_outputs}")
    central_input = np.concatenate(client_outputs,axis=1)
    logging.info(f"Prediction input shape: {central_input.shape}")
    try:
        central_output = vs.forward_pass(central_model, central_input)
    except ValueError as e:
        logging.error(f"Error during prediction: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error during prediction: {str(e)}")

    prediction = (central_output > 0.5).astype(int).item()

    return {"prediction": prediction}

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    uvicorn.run(app, host="0.0.0.0", port=8000)