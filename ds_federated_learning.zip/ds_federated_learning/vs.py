# vs.py
import numpy as np
import logging

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Layer_Dense:
    def __init__(self, n_inputs, n_neurons):
        self.weights = 0.01 * np.random.randn(n_inputs, n_neurons)
        self.biases = np.zeros((1, n_neurons))
        self.dweights = np.zeros_like(self.weights)
        self.dbiases = np.zeros_like(self.biases)
        logger.debug(f"Initialized Layer_Dense with input shape: {n_inputs}, neurons: {n_neurons}")
        
    def forward(self, inputs):
        self.inputs = inputs
        logger.debug(f"Layer forward - Input shape: {inputs.shape}, Weight shape: {self.weights.shape}, Bias shape: {self.biases.shape}")
        if inputs.ndim == 1:
            inputs = inputs.reshape(1, -1)
            logger.debug(f"Reshaped 1D input to: {inputs.shape}")
        if inputs.shape[1] != self.weights.shape[0]:
            raise ValueError(f"Input shape {inputs.shape} does not match weight shape {self.weights.shape}")
        self.output = np.dot(inputs, self.weights) + self.biases
        logger.debug(f"Layer output shape: {self.output.shape}")
        
    def backward(self, dvalues):
        self.dweights = np.dot(self.inputs.T, dvalues)
        self.dbiases = np.sum(dvalues, axis=0, keepdims=True)
        self.dinputs = np.dot(dvalues, self.weights.T)

class Activation_ReLU:
    def forward(self, inputs):
        self.inputs = inputs
        self.output = np.maximum(0, inputs)
        logger.debug(f"ReLU - Input shape: {inputs.shape}, Output shape: {self.output.shape}")
        
    def backward(self, dvalues):
        self.dinputs = dvalues.copy()
        self.dinputs[self.inputs <= 0] = 0

class Activation_Sigmoid:
    def forward(self, inputs):
        self.inputs = inputs
        self.output = 1 / (1 + np.exp(-inputs))
        logger.debug(f"Sigmoid - Input shape: {inputs.shape}, Output shape: {self.output.shape}")
        
    def backward(self, dvalues):
        self.dinputs = dvalues * self.output * (1 - self.output)

def create_model(n_features, is_central=False):
    if is_central:
        model = [
            Layer_Dense(n_features, 256),
            Activation_ReLU(),
            Layer_Dense(256, 128),
            Activation_ReLU(),
            Layer_Dense(128, 64),
            Activation_ReLU(),
            Layer_Dense(64, 1),
            Activation_Sigmoid()
        ]
    else:
        model = [
            Layer_Dense(n_features, 64),
            Activation_ReLU(),
            Layer_Dense(64, 128),
            Activation_ReLU(),
            Layer_Dense(128, 64),
            Activation_ReLU()
        ]
    logger.debug(f"Created {'central' if is_central else 'client'} model with {len(model)} layers")
    return model

def forward_pass(model, inputs):
    logger.debug(f"Starting forward pass with input shape: {inputs.shape}")
    if inputs.ndim == 1:
        inputs = inputs.reshape(1, -1)
        logger.debug(f"Reshaped 1D input to: {inputs.shape}")
    for i, layer in enumerate(model):
        logger.debug(f"Layer {i} - Input shape: {inputs.shape}")
        layer.forward(inputs)
        inputs = layer.output
        logger.debug(f"Layer {i} - Output shape: {inputs.shape}")
    return inputs

def backward_pass(model, dvalues):
    for layer in reversed(model):
        layer.backward(dvalues)
        dvalues = layer.dinputs
    return dvalues

def calculate_loss(y_pred, y_true):
    epsilon = 1e-15
    y_pred = np.clip(y_pred, epsilon, 1 - epsilon)
    return -np.mean(y_true * np.log(y_pred) + (1 - y_true) * np.log(1 - y_pred))

def update_model(model, learning_rate=0.01):
    for layer in model:
        if isinstance(layer, Layer_Dense):
            layer.weights -= learning_rate * layer.dweights
            layer.biases -= learning_rate * layer.dbiases

def calculate_accuracy(y_pred, y_true):
    predictions = (y_pred > 0.5).astype(int)
    return np.mean(predictions == y_true)