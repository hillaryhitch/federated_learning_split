# client_server.py
import uvicorn
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np
import vs
import joblib
import requests
import pandas as pd
import logging
import sys

app = FastAPI()

logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class ClientConfig(BaseModel):
    client_id: int
    central_server_url: str

class ForwardRequest(BaseModel):
    client_id: int

class BackwardRequest(BaseModel):
    client_id: int
    gradients: list

class PredictRequest(BaseModel):
    client_id: int  

class ClientData:
    def __init__(self, data_path, pred_data_path, client_id):
        self.train_data = pd.read_csv(data_path)
        self.pred_data = pd.read_csv(pred_data_path)
        self.ydata=pd.read_csv('train_credit_risk.csv')#['credit_risk'].values
        # label_mapping = {'Low': 0, 'Medium': 1, 'High': 2}
        # self.ydata['credit_risk'] = self.ydata['credit_risk'].map(label_mapping)
        self.y=self.ydata['credit_risk'].values
        self.client_id = client_id
        self.X = self.train_data.drop(['client_id'],axis=1)
        self.n_features = self.X.shape[1]
        self.client_ids = self.train_data['client_id'].values  
        self.pred_client_ids = self.pred_data['client_id'].values  
        self.X_pred = self.pred_data.drop(['client_id'],axis=1).values
        logger.info(f"Client {client_id} initialized with {self.n_features} features, {len(self.X)} train samples, and {len(self.X_pred)} prediction samples")
        logger.debug(f"Train data shape: {self.X.shape}, Pred data shape: {self.X_pred.shape}")

client_config = None
client_model = None
client_data = None

@app.post("/configure")
async def configure(config: ClientConfig):
    global client_config, client_model, client_data
    client_config = config
    client_model = vs.create_model(client_data.n_features)
    
    # Register with central server
    client_url = f"http://localhost:{8000 + config.client_id}"
    response = requests.post(f"{config.central_server_url}/register_client", 
                             json={"client_id": config.client_id, "url": client_url})
    if response.status_code != 200:
        logger.error(f"Failed to register with central server. Status code: {response.status_code}")
        return {"error": "Failed to register with central server"}
    
    logger.info(f"Client {config.client_id} configured successfully")
    return {"message": "Client configured successfully"}

@app.post("/forward")
async def forward(request: ForwardRequest):
    if client_model is None:
        logger.error("Client not configured")
        return {"error": "Client not configured"}
    
    logger.debug(f"Forward pass input shape: {client_data.X.shape}")
    output = vs.forward_pass(client_model, client_data.X)
    logger.info(f"Forward pass output shape: {output.shape}")
    
    return {"output": output.tolist(), "labels": client_data.y.tolist()}

@app.post("/backward")
async def backward(request: BackwardRequest):
    if client_model is None:
        logger.error("Client not configured")
        return {"error": "Client not configured"}
    
    gradients = np.array(request.gradients)
    logger.debug(f"Backward pass gradient shape: {gradients.shape}")
    vs.backward_pass(client_model, gradients)
    vs.update_model(client_model)
    
    logger.info("Backward pass completed")
    return {"message": "Backward pass completed"}

@app.post("/predict")
async def predict(request: PredictRequest):
    if client_model is None:
        logger.error("Client not configured")
        return {"error": "Client not configured"}
    
    user_data = client_data.X_pred[client_data.pred_client_ids == request.client_id]  
    if user_data.size == 0:
        logger.warning(f"Client {request.client_id} not found in prediction data for client {client_data.client_id}")
        return {"output": []}
    
    logger.debug(f"User data shape before reshape: {user_data.shape}")
    if user_data.ndim == 1:
        user_data = user_data.reshape(1, -1)
    logger.debug(f"User data shape after reshape: {user_data.shape}")
    
    output = vs.forward_pass(client_model, user_data)
    logger.info(f"Prediction output shape: {output.shape}")
    
    return {"output": output.tolist()}

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python client_server.py <client_id> <data_path> <pred_data_path>")
        sys.exit(1)
    
    client_id = int(sys.argv[1])
    data_path = sys.argv[2]
    pred_data_path = sys.argv[3]
    client_data = ClientData(data_path, pred_data_path, client_id)
    
    port = 8000 + client_id
    logger.info(f"Starting client {client_id} on http://localhost:{port}")
    uvicorn.run(app, host="0.0.0.0", port=port)